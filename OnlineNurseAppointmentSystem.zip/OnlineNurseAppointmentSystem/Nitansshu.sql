drop database db;
create database db;
USE db;
CREATE TABLE customer (
customerId INT PRIMARY KEY,
customerName VARCHAR(50) NOT NULL,
customerEmail VARCHAR(50) NOT NULL,
mobileno VARCHAR(10) NOT NULL,
address VARCHAR(50) NOT NULL,
gender VARCHAR(10) NOT NULL
);


CREATE TABLE nurse (
nurseId INT PRIMARY KEY,
nurseName VARCHAR(50) NOT NULL,
mobileno VARCHAR(10) NOT NULL,
address VARCHAR(50) NOT NULL
);


CREATE TABLE service (
serviceId INT PRIMARY KEY,
serviceName VARCHAR(50) NOT NULL,
serviceDescription VARCHAR(50) NOT NULL,
charges FLOAT NOT NULL
);


create table Appointment (
appointmentId int PRIMARY KEY,
customerId int,
nurseId int,
serviceId int,
appointmentDate date,
appointmentStatus boolean,
FOREIGN KEY(customerId) REFERENCES customer(customerId),
FOREIGN KEY(nurseId) REFERENCES nurse(nurseId),
FOREIGN KEY(serviceId) REFERENCES service(serviceId)
);

create table Payment (
paymentId int PRIMARY KEY,
appointmentId int,
customerId int,
nurseId int,
cardNumber long,
nameOnCard varchar(50),
expiryDate date,
securityCode int,

FOREIGN KEY(appointmentId) REFERENCES appointment(appointmentId),
FOREIGN KEY(customerId) REFERENCES customer(customerId),
FOREIGN KEY(nurseId) REFERENCES nurse(nurseId)
);

-- DROP TABLE Appointment;
show tables;
desc appointment;

select * from customer;
select * from nurse;
select * from service;
select * from appointment;
select * from payment;

