package com.nurse.entity;

import java.util.Objects;

public class Payment {
    private int paymentId;
    private int appointmentId;
    private int customerId;
    private int nurseId;
    private int cardNumber;
    private String nameOnCard;
    private String expiryDate;
    private int securityCode;

    public Payment(int paymentId, int customerId, int appointmentId, int nurseId, int cardNumber, String nameOnCard, String expiryDate, int securityCode) {
        this.paymentId = paymentId;
        this.customerId = customerId;
        this.appointmentId = appointmentId;
        this.nurseId = nurseId;
        this.cardNumber = cardNumber;
        this.nameOnCard = nameOnCard;
        this.expiryDate = expiryDate;
        this.securityCode = securityCode;
    }

    public Payment(){

    }
    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getNurseId() {
        return nurseId;
    }

    public void setNurseId(int nurseId) {
        this.nurseId = nurseId;
    }

    public int getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(int cardNumber) {this.cardNumber = cardNumber; }

    public String getNameOnCard() {
        return nameOnCard;
    }

    public void setNameOnCard(String nameOnCard) {
        this.nameOnCard = nameOnCard;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public int getSecurityCode() {
        return securityCode;
    }

    public void setSecurityCode(int securityCode) {
        this.securityCode = securityCode;
    }

    @Override
    public String toString() {
        return "Payment [paymentID=" + paymentId + ", appointmentID=" + appointmentId + ", customerId=" + customerId+ ", nurseId=" + nurseId+ ", cardNumber=" + cardNumber + ", nameOnCard=" + nameOnCard + ", expiryDate="
                + expiryDate + ", securityCode=" + securityCode + "]";
    }

    @Override
    public int hashCode() {
        return Objects.hash(paymentId,appointmentId,customerId, nurseId, cardNumber, nameOnCard, expiryDate, securityCode);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Payment other = (Payment) obj;

        return Objects.equals(paymentId, other.paymentId)
                && Objects.equals(appointmentId, other.appointmentId)
                && Objects.equals(customerId, other.customerId)
                && Objects.equals(nurseId, other.nurseId)
                && Objects.equals(cardNumber, other.cardNumber)
                && Objects.equals(nameOnCard, other.nameOnCard)
                && Objects.equals(expiryDate, other.expiryDate)
                && Objects.equals(securityCode, other.securityCode);
    }
}
