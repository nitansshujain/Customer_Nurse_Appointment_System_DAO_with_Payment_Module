package com.nurse.dao;

import com.nurse.entity.Payment;

import java.util.List;

public interface PaymentDAO {
    int insert(Payment payment);
    int update(Payment payment);
    int delete(int paymentId);
    Payment viewOne(int paymentId);
    List<Payment> viewAll();
}
