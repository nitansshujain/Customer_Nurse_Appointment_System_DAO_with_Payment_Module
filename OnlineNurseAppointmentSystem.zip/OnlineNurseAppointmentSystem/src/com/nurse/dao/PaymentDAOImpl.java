package com.nurse.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nurse.entity.Payment;
import com.nurse.utility.DBUtil;
import com.nurse.entity.Customer;

public class PaymentDAOImpl implements PaymentDAO {

    @Override
    public int insert(Payment payment) {
        int status = 0;

        Connection connPayment = null;
        PreparedStatement pstPayment = null;

        String sql = new String("INSERT INTO payment VALUES(?,?,?,?,?,?,?,?)");

        try {
            connPayment = DBUtil.createConnection();

            pstPayment = connPayment.prepareStatement(sql);
            pstPayment.setInt(1,payment.getPaymentId());
            pstPayment.setInt(2,payment.getAppointmentId());
            pstPayment.setInt(3,payment.getCustomerId());
            pstPayment.setInt(4,payment.getNurseId());

            pstPayment.setInt(5, payment.getCardNumber());
            pstPayment.setString(6, payment.getNameOnCard());
            pstPayment.setString(7, payment.getExpiryDate());
            pstPayment.setInt(8, payment.getSecurityCode());


            status = pstPayment.executeUpdate();

//			System.out.println("Record inserted successfully with Payment ID " + payment.getPaymentId());
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        } finally {
            try {
                DBUtil.closeConnection();
            } catch (SQLException se) {
                System.out.println("Problems in closing connection");
            }
        }
        return status;
    }

    @Override
    public int update(Payment payment) {
        int status = 0;

        Connection connPayment = null;
        PreparedStatement pstPayment = null;

        String sql = new String("UPDATE payment SET appointmentID=?, customerId=?, nurseID=?, cardNumber=?, nameOnCard=?, expiryDate=?, securityCode=?"
                + "  WHERE paymentID=?");

        try {
            connPayment = DBUtil.createConnection();

            pstPayment = connPayment.prepareStatement(sql);
            pstPayment.setInt(1,payment.getAppointmentId());
            pstPayment.setInt(2,payment.getCustomerId());
            pstPayment.setInt(3,payment.getNurseId());

            pstPayment.setInt(4, payment.getCardNumber());
            pstPayment.setString(5, payment.getNameOnCard());
            pstPayment.setString(6, payment.getExpiryDate());
            pstPayment.setInt(7, payment.getSecurityCode());
            pstPayment.setInt(8,payment.getPaymentId());

            status = pstPayment.executeUpdate();

//			System.out.println("Record updated successfully with Payment ID " + payment.getPaymentId());
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        } finally {
            try {
                DBUtil.closeConnection();
            } catch (SQLException se) {
                System.out.println("Problems in closing connection");
            }
        }
        return status;
    }


    @Override
    public int delete(int paymentId) {
        int status = 0;

        Connection connPayment = null;
        PreparedStatement pstPayment = null;

        String sql = new String("DELETE FROM payment WHERE paymentId=?");

        try {
            connPayment = DBUtil.createConnection();

            pstPayment = connPayment.prepareStatement(sql);
            pstPayment.setInt(1, paymentId);


            status = pstPayment.executeUpdate();

//			System.out.println("Record deleted successfully with payment ID " + paymentId);
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        } finally {
            try {
                DBUtil.closeConnection();
            } catch (SQLException se) {
                System.out.println("Problems in closing connection");
            }
        }
        return status;

    }

    @Override
    public Payment viewOne(int paymentId) {
        Connection connPayment = null;
        PreparedStatement pstPayment = null;

        String sql = new String("SELECT * FROM payment WHERE paymentId=?");

        Payment payment = null;
        ResultSet rsPayment = null;

        try {
            connPayment = DBUtil.createConnection();

            pstPayment = connPayment.prepareStatement(sql);
            pstPayment.setInt(1, paymentId);

            rsPayment = pstPayment.executeQuery();

            while(rsPayment.next()){
//                payment = new Payment(paymentId,sql,sql,sql,sql,sql,sql,sql);
                payment = new Payment();
                payment.setPaymentId(rsPayment.getInt("paymentId"));
                payment.setAppointmentId(rsPayment.getInt("appointmentId"));
                payment.setCustomerId(rsPayment.getInt("customerId"));
                payment.setNurseId(rsPayment.getInt("nurseId"));
                payment.setCardNumber(rsPayment.getInt("cardNumber"));
                payment.setNameOnCard(rsPayment.getString("nameOnCard"));
                payment.setExpiryDate(rsPayment.getString("expiryDate"));
                payment.setSecurityCode(rsPayment.getInt("securityCode"));

            }
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        } finally {
            try {
                DBUtil.closeConnection();
            } catch (SQLException se) {
                System.out.println("Problems in closing connection");
            }
        }

        return payment;
    }

    @Override
    public List<Payment> viewAll() {

        Connection connPayment = null;
        PreparedStatement pstPayment = null;

        ResultSet rsPayment = null;
        String sql = new String("SELECT * FROM payment");

        Payment payment = null;
        List<Payment>payments = new ArrayList<>();
        try {
            connPayment = DBUtil.createConnection();

            pstPayment = connPayment.prepareStatement(sql);


            rsPayment = pstPayment.executeQuery();

            while(rsPayment.next()){
//                payment = new Payment(0,sql,sql,sql,sql,sql,sql,sql);
                payment = new Payment();
                payment.setPaymentId(rsPayment.getInt("paymentId"));
                payment.setAppointmentId(rsPayment.getInt("appointmentId"));
                payment.setCustomerId(rsPayment.getInt("customerId"));
                payment.setNurseId(rsPayment.getInt("nurseId"));
                payment.setCardNumber(rsPayment.getInt("cardNumber"));
                payment.setNameOnCard(rsPayment.getString("nameOnCard"));
                payment.setExpiryDate(rsPayment.getString("expiryDate"));
                payment.setSecurityCode(rsPayment.getInt("securityCode"));

                payments.add(payment);
            }
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        } finally {
            try {
                DBUtil.closeConnection();
            } catch (SQLException se) {
                System.out.println("Problems in closing connection");
            }
        }

        return payments;
    }

}
