package com.nurse.service;

import com.nurse.entity.Customer;
import com.nurse.entity.Payment;

import java.util.List;

public interface PaymentService {
    public int insertPayment(Payment payment);
    public int updatePayment(Payment payment);
    public int deletePayment(int paymentId);
    public Payment viewPayment(int paymentId);
    public List<Payment> viewPayments();
}
