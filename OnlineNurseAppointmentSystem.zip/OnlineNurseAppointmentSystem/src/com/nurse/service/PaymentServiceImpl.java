package com.nurse.service;

import com.nurse.dao.PaymentDAO;

import com.nurse.dao.PaymentDAOImpl;
import com.nurse.entity.Payment;

import java.util.List;

public class PaymentServiceImpl implements PaymentService {
    private PaymentDAO paymentDAO;

    public PaymentServiceImpl() {
        paymentDAO = new PaymentDAOImpl();
    }

    @Override
    public int insertPayment(Payment payment) {
        return paymentDAO.insert(payment);
    }

    @Override
    public int updatePayment(Payment payment) {
        return paymentDAO.update(payment);
    }

    @Override
    public int deletePayment(int paymentId) {
        return paymentDAO.delete(paymentId);
    }

    @Override
    public Payment viewPayment(int paymentId) {
        return paymentDAO.viewOne(paymentId);
    }

    @Override
    public List<Payment> viewPayments() {
        return paymentDAO.viewAll();
    }
}
