package com.nurse.client;

import java.util.List;
import java.util.Scanner;

import com.nurse.controllers.AppointmentController;
import com.nurse.controllers.CustomerController;
import com.nurse.controllers.NurseController;
import com.nurse.controllers.ServicesController;
import com.nurse.controllers.PaymentController;
import com.nurse.entity.*;

public class CustomerClient {

	public static void main(String[] args) {
		int choice = -1;
		int innerChoice = -1;
		
		int custId = 0;
		int nurseId= 0;
		int serviceId = 0, cvv=0, pin=0;
		int appointmentId=0;
		int paymentId=0;

		
		
		CustomerController customerController = new CustomerController();
		NurseController nurseController = new NurseController();
		ServicesController serviceController = new ServicesController();
		AppointmentController appointmentController = new AppointmentController();
		PaymentController paymentController = new PaymentController();

		Customer customer = null;
		Nurse nurse = null;
		Services service = null;
		Appointment appointment = null;
		Payment payment = null;

		Scanner scInput = new Scanner(System.in);
		do{
			System.out.println("Following is the choice:");
			System.out.println("1. Customer");
			System.out.println("2. Nurse");
			System.out.println("3. Services");
			System.out.println("4. Appointment");
			System.out.println("5. Payment");
			System.out.println("0. Exit");
			
			choice = Integer.parseInt(scInput.nextLine());

			switch (choice) {
				case 1 -> {
					do {
						System.out.println("Following is the choice:");
						System.out.println("1. Insert Customer");
						System.out.println("2. Update Customer");
						System.out.println("3. Delete Customer");
						System.out.println("4. View single customer");
						System.out.println("5. View all customers");
						System.out.println("0. Exit");

						innerChoice = Integer.parseInt(scInput.nextLine());

						switch (innerChoice) {
							case 1 -> {
								customer = getCustomer(scInput);
								customerController.insertCustomer(customer);
							}
							case 2 -> {
								customer = getCustomer(scInput);
								customerController.updateCustomer(customer);
							}
							case 3 -> {
								System.out.print("Enter customer ID: ");
								custId = Integer.parseInt(scInput.nextLine());
								customerController.deleteCustomer(custId);
							}
							case 4 -> {
								System.out.print("Enter customer ID: ");
								custId = Integer.parseInt(scInput.nextLine());
								customer = customerController.viewCustomer(custId);
								System.out.println(customer);
							}
							case 5 -> {
								List<Customer> customers = customerController.viewAllCustomers();
								System.out.println("Following is the customer list:");
								for (Customer cust : customers) {
									System.out.println(cust);
								}
							}
						}
					} while (innerChoice != 0);
				}
				case 2 -> {
					do {
						System.out.println("Following is the choice:");
						System.out.println("1. Insert Nurse");
						System.out.println("2. Modify Nurse");
						System.out.println("3. Delete Nurse");
						System.out.println("4. View single nurse");
						System.out.println("5. View all nurses");
						System.out.println("0. Exit");

						innerChoice = Integer.parseInt(scInput.nextLine());

						switch (innerChoice) {
							case 1 -> {
								nurse = getNurse(scInput);
								nurseController.insertNurse(nurse);
							}
							case 2 -> {
								nurse = getNurse(scInput);
								nurseController.updateNurse(nurse);
							}
							case 3 -> {
								System.out.print("Enter nurse ID: ");
								nurseId = Integer.parseInt(scInput.nextLine());
								nurseController.deleteNurse(nurseId);
							}
							case 4 -> {
								System.out.print("Enter nurse ID: ");
								nurseId = Integer.parseInt(scInput.nextLine());
								nurse = nurseController.viewNurse(nurseId);
								System.out.println(nurse);
							}
							case 5 -> {
								List<Nurse> nurses = nurseController.viewAllNurses();
								System.out.println("Following is the nurses list:");
								for (Nurse nrse : nurses) {
									System.out.println(nrse);
								}
							}
						}
					} while (innerChoice != 0);
				}
				case 3 -> {
					do {
						System.out.println("Following is the choice:");
						System.out.println("1. Insert Service");
						System.out.println("2. Modify Service");
						System.out.println("3. Delete Service");
						System.out.println("4. View single service");
						System.out.println("5. View all services");
						System.out.println("0. Exit");

						innerChoice = Integer.parseInt(scInput.nextLine());

						switch (innerChoice) {
							case 1 -> {
								service = getServices(scInput);
								serviceController.insertService(service);
							}
							case 2 -> {
								service = getServices(scInput);
								serviceController.updateService(service);
							}
							case 3 -> {
								System.out.print("Enter service ID: ");
								serviceId = Integer.parseInt(scInput.nextLine());
								serviceController.deleteService(serviceId);
							}
							case 4 -> {
								System.out.print("Enter service ID: ");
								serviceId = Integer.parseInt(scInput.nextLine());
								service = serviceController.viewService(serviceId);
								System.out.println(service);
							}
							case 5 -> {
								List<Services> services = serviceController.viewAllServices();
								System.out.println("Following is the services list:");
								for (Services nrse : services) {
									System.out.println(nrse);
								}
							}
						}
					} while (innerChoice != 0);
				}
				case 4 -> {
					do {

						System.out.println("Following is the choice:");
						System.out.println("1. Insert Appointment");
						System.out.println("2. Update Appointment");
						System.out.println("3. Delete Appointment");
						System.out.println("4. View single Appointment");
						System.out.println("5. View all Appointment");
						System.out.println("0. Exit");

						innerChoice = Integer.parseInt(scInput.nextLine());

						switch (innerChoice) {
							case 1 -> {
								appointment = getAppointment(scInput);
								appointmentController.insertAppointment(appointment);
							}
							case 2 -> {
								appointment = getAppointment(scInput);
								appointmentController.updateAppointment(appointment);
							}
							case 3 -> {
								System.out.print("Enter Appointment ID: ");
								appointmentId = Integer.parseInt(scInput.nextLine());
								appointmentController.deleteAppointment(appointmentId);
							}
							case 4 -> {
								System.out.print("Enter Appointment ID: ");
								appointmentId = Integer.parseInt(scInput.nextLine());
								appointment = appointmentController.veiwAppointment(appointmentId);
								System.out.println(appointment);
							}
							case 5 -> {
								List<Appointment> appointments = appointmentController.veiwAllAppointment();
								System.out.println("Following is the appointment list:");
								for (Appointment ap : appointments) {
									System.out.println(ap);
								}
							}
						}
					} while (innerChoice != 0);
				}

				case 5 -> {
					do {

						System.out.println("Following is the choice:");
						System.out.println("1. Insert Payment");
						System.out.println("2. Update Payment");
						System.out.println("3. Delete Payment");
						System.out.println("4. View single Payment");
						System.out.println("5. View all Payments");
						System.out.println("0. Exit");

						innerChoice = Integer.parseInt(scInput.nextLine());

						switch (innerChoice) {
							case 1 -> {
								payment = getPayment(scInput);
								paymentController.insertPayment(payment);
							}
							case 2 -> {
								payment = getPayment(scInput);
								paymentController.updatePayment(payment);
							}
							case 3 -> {
								System.out.print("Enter Payment ID: ");
								paymentId = Integer.parseInt(scInput.nextLine());
								paymentController.deletePayment(paymentId);
							}
							case 4 -> {
								System.out.print("Enter Payment ID: ");
								paymentId = Integer.parseInt(scInput.nextLine());
								payment = paymentController.viewPayment(paymentId);
								System.out.println(payment);
							}
							case 5 -> {
								List<Payment> payments = paymentController.veiwAllPayments();
								System.out.println("Following is the Payment list:");
								for (Payment ap : payments) {
									System.out.println(ap);
								}
							}
						}
					} while (innerChoice != 0);
				}
			}
		}while(choice != 0);
		scInput.close();
	}

	private static Payment getPayment(Scanner scInput) {
		int paymentId;
		int appointmentId;
		int customerId;
		int nurseId;
		int cardNumber;
		String nameOnCard;
		String expiryDate;
		int securityCode;

		Payment payment;
		System.out.print("Enter Payment ID: ");
		paymentId = Integer.parseInt(scInput.nextLine());

		System.out.print("Enter Appointment ID: ");
		appointmentId = Integer.parseInt(scInput.nextLine());

		System.out.print("Enter Customer ID: ");
		customerId = Integer.parseInt(scInput.nextLine());

		System.out.print("Enter Nurse ID: ");
		nurseId = Integer.parseInt(scInput.nextLine());

		System.out.print("Enter Card Number: ");
		cardNumber = Integer.parseInt(scInput.nextLine());

		System.out.print("Enter the Name on your Card: ");
		nameOnCard = scInput.nextLine();

		System.out.print("Enter Expiry Date: ");
		expiryDate = scInput.nextLine();

		System.out.print("Enter Security Code: ");
		securityCode = Integer.parseInt(scInput.nextLine());

		payment = new Payment(paymentId, appointmentId, customerId, nurseId, cardNumber, nameOnCard, expiryDate, securityCode);
		return payment;
	}

	private static Appointment getAppointment(Scanner scInput) {
		int appointmentId;
		int custId;
		int nurseId;
		int serviceId;
		String appointmentDate;
		boolean appointmentStatus;
		Appointment appointment;
		System.out.print("Enter Appointment ID: ");
		appointmentId = Integer.parseInt(scInput.nextLine());
		System.out.print("Enter User ID: ");
		custId = Integer.parseInt(scInput.nextLine());
		System.out.print("Enter NurseId: ");
		nurseId = Integer.parseInt(scInput.nextLine());
		System.out.print("Enter ServiceId: ");
		serviceId = Integer.parseInt(scInput.nextLine());
		System.out.print("Enter Appointment Date : ");
		appointmentDate = scInput.nextLine();
		appointmentStatus = true;
		appointment = new Appointment(appointmentId, custId, nurseId, serviceId, appointmentDate, appointmentStatus);
		return appointment;
	}

	private static Services getServices(Scanner scInput) {
		int serviceId;
		String name;
		String description;
		float charges;
		Services service;
		System.out.print("Enter service ID: ");
		serviceId = Integer.parseInt(scInput.nextLine());
		System.out.print("Enter service name: ");
		name = scInput.nextLine();
		System.out.print("Enter service description: ");
		description = scInput.nextLine();
		System.out.print("Enter service charges: ");
		charges = Float.parseFloat(scInput.nextLine());
		service = new Services(serviceId, name, description, charges);
		return service;
	}

	private static Nurse getNurse(Scanner scInput) {
		int nurseId;
		String name;
		String mobileNo;
		String address;
		Nurse nurse;
		System.out.print("Enter nurse ID: ");
		nurseId = Integer.parseInt(scInput.nextLine());
		System.out.print("Enter name: ");
		name = scInput.nextLine();
		System.out.print("Enter mobile number: ");
		mobileNo = scInput.nextLine();
		System.out.print("Enter address: ");
		address = scInput.nextLine();
		nurse = new Nurse(nurseId, name, mobileNo, address);
		return nurse;
	}

	private static Customer getCustomer(Scanner scInput) {
		int custId;
		String name;
		String email;
		String mobileNo;
		String address;
		String gender;
		Customer customer;
		System.out.print("Enter customer ID: ");
		custId = Integer.parseInt(scInput.nextLine());
		System.out.print("Enter name: ");
		name = scInput.nextLine();
		System.out.print("Enter email: ");
		email = scInput.nextLine();
		System.out.print("Enter mobile number: ");
		mobileNo = scInput.nextLine();
		System.out.print("Enter address: ");
		address = scInput.nextLine();
		System.out.print("Enter gender: ");
		gender = scInput.nextLine();
		customer = new Customer(custId, name, email, mobileNo, address, gender);
		return customer;
	}
}
