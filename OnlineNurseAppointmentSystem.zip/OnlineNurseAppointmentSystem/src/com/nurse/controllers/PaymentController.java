package com.nurse.controllers;

import com.nurse.entity.Appointment;
import com.nurse.entity.Payment;
import com.nurse.service.AppointmentService;
import com.nurse.service.AppointmentServiceImpl;
import com.nurse.service.PaymentService;
import com.nurse.service.PaymentServiceImpl;

import java.util.List;

public class PaymentController {
    private PaymentService paymentService;

    public PaymentController() {
        paymentService = new PaymentServiceImpl();
    }

    public void insertPayment(Payment payment) {
        int status = paymentService.insertPayment(payment);

        if(status > 0) {
            System.out.println("Record inserted successfully.");
        }else {
            System.out.println("Record couldn't be inserted");
        }
    }

    public void updatePayment(Payment payment) {
        int status = paymentService.updatePayment(payment);

        if(status > 0) {
            System.out.println("Record updated successfully.");
        }else {
            System.out.println("Record couldn't be updated");
        }
    }

    public void deletePayment(int paymentId) {
        int status = paymentService.deletePayment(paymentId);

        if(status > 0) {
            System.out.println("Record deleted successfully.");
        }else {
            System.out.println("Record couldn't be deleted");
        }
    }

    public Payment viewPayment(int paymentId) {
        Payment payment = paymentService.viewPayment(paymentId);
        return payment;
    }

    public List<Payment> veiwAllPayments(){
        return paymentService.viewPayments();
    }
}
