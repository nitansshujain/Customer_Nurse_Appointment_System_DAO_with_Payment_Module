/**
 * 
 */
/**
 * 
 */
module OnlineNurseAppointmentSystem {
	requires java.sql;
}